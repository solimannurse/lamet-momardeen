import type { Metadata, Viewport } from 'next';
import type { ReactNode } from 'react';
import './globals.css';
import './study.css';
import './polish.css';
export const metadata:Metadata={title:'لمة ممرضين | مساحة الطالب',description:'مساحة هادئة لطلاب التمريض. تعلّم بالمحاضرات والبطاقات، وراجع أسئلتك وتابع تقدّمك الدراسي.',manifest:'/manifest.webmanifest',icons:{icon:'/icon.svg',apple:'/icons/icon-192.png'}};
export const viewport:Viewport={width:'device-width',initialScale:1,themeColor:'#247866'};
export default function RootLayout({children}:{children:ReactNode}){return <html lang="ar" dir="rtl" suppressHydrationWarning><body>{children}</body></html>}

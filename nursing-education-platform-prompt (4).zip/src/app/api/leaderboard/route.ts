import {and,eq,isNotNull} from 'drizzle-orm';
import {db} from '@/db';
import {students} from '@/db/schema';
import {requireUser,resultError} from '@/lib/server';
export async function GET(){try{const me=await requireUser();const rows=await db.select({id:students.id,name:students.name,study:students.study}).from(students).where(and(eq(students.year,me.year),eq(students.blocked,false),isNotNull(students.email),eq(students.role,'student')));return Response.json({leaders:rows.sort((a,b)=>b.study.points-a.study.points).slice(0,15).map(s=>({name:s.name.split(' ')[0],points:s.study.points,self:s.id===me.id}))})}catch(e){return resultError(e)}}

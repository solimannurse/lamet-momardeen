import { eq, desc } from 'drizzle-orm';
import { db } from '@/db';
import { students, messages } from '@/db/schema';
import { workspace, requireUser, resultError, jsonBody, AppError } from '@/lib/server';
import {validStudy} from '@/lib/validation';
import { uid, type Study } from '@/lib/learning';
export const dynamic='force-dynamic';
export async function GET(){try{return Response.json(await workspace(),{headers:{'Cache-Control':'private, no-store'}})}catch(e){return resultError(e)}}
export async function PATCH(r:Request){try{const u=await requireUser(),{study,forUser}=await jsonBody(r,400000);if(forUser&&forUser!==u.id)throw new AppError('تغيّرت جلسة الحساب. أعد تحميل الصفحة.',409);if(!validStudy(study))throw new AppError('بيانات المذاكرة غير مكتملة.');const next={...u.study,...study,activity:study.activity.slice(0,100),tasks:study.tasks.slice(0,500)} as Study;await db.update(students).set({study:next,lastSeen:new Date()}).where(eq(students.id,u.id));return Response.json({saved:true})}catch(e){return resultError(e)}}
export async function POST(r:Request){try{const u=await requireUser(),b=await jsonBody(r);if(b.action==='inbox')return Response.json({messages:await db.select().from(messages).where(eq(messages.studentId,u.id)).orderBy(desc(messages.created)).limit(50)});if(b.action==='question'&&typeof b.body==='string'&&b.body.trim().length>=3){await db.insert(messages).values({id:uid(),studentId:u.id,subject:String(b.subject||'سؤال دراسي').slice(0,200),body:b.body.trim().slice(0,3000)});return Response.json({ok:true})}throw new AppError('راجع نص السؤال.')}catch(e){return resultError(e)}}

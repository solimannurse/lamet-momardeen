import {PlatformProvider} from '@/components/platform';
import {StudentShell} from '@/components/shell';
export default function Home(){return <PlatformProvider><StudentShell/></PlatformProvider>}

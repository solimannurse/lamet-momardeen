import type { Metadata } from 'next';
import './admin.css';
import {AdminApp} from '@/components/admin';
export const metadata:Metadata={title:'لوحة الإدارة | لمة ممرضين',robots:{index:false,follow:false}};
export default function AdminPage(){return <AdminApp/>}
